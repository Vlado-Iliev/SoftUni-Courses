from project.sports_car import SportsCar

c1 = SportsCar()

print(c1.move())
print(c1.drive())
print(c1.race())
