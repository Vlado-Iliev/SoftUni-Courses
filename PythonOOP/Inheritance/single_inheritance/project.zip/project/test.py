from project.dog import Dog
from project.animal import Animal

d1 = Dog()

print(d1.eat())
print(d1.bark())