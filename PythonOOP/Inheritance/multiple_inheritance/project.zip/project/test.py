from project.teacher import Teacher

t1 = Teacher()
print(t1.sleep())
print(t1.teach())
print(t1.get_fired())
