from project.cat import Cat
from project.dog import Dog

d1 = Dog()
c1 = Cat()

print(d1.eat())
print(d1.bark())
print(c1.eat())
print(c1.meow())