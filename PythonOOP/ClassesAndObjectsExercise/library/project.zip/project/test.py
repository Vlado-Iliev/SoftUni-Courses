library = {132:{'gosho':17,'pesho':2}}

x = 'gosho'
library[132].pop(x)

print(library)